from django.apps import AppConfig


class MypatientConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "mypatient"
